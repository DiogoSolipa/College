#include <stdio.h>
#include <math.h>
#include "complexos.h"

#define PI 3.14159265359

//le os valores do utilizador

struct complexo le_complexo(){

    struct complexo c; 

    printf("Introduza a parte real: ");
    scanf("%d", &c.real);
    printf("Introduza a parte imaginaria: ");
    scanf("%d", &c.img);

    return c;
}

void escreve_complexo(struct complexo c){

    printf("%d + %di\n", c.real, c.img);
}

struct complexo soma_complexo(struct complexo c1, struct complexo c2){

    struct complexo c;

    c.real = c1.real + c2.real;
    c.img = c1.img + c2.img;

    return c;
}

double modulo_complexo(struct complexo c){

    return sqrt(pow(c.real, 2) + pow(c.img, 2));
}

double argumento_complexo(struct complexo c){

    if(c.real != 0)
    {
        return atan(c.img / c.real);
    }else{
        if(c.img > 0)
        {
            return PI / 2;

        }else{

            return -PI / 2;
        }
    }
}
