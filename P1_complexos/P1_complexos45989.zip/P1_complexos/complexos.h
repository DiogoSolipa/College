#include <stdio.h>

struct complexo {

    int real, img;
};

struct complexo le_complexo();
void escreve_complexo(struct complexo c);
struct complexo soma_complexo(struct complexo c1, struct complexo c2);
double modulo_complexo(struct complexo c);
double argumento_complexo(struct complexo c);