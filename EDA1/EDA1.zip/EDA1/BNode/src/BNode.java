public class BNode<E> {

    E elemento;
    BNode<E> esq;
    BNode<E> dir;
    
}
