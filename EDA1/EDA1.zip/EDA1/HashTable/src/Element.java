public class Element<T> {

    T element;

    Element() {
        this(null);
    }

    Element(T x) {

        element = x;
    }
}
