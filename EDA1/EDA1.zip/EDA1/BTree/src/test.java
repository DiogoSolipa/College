public class test extends ArrayStack {

    public static void main (String [] args){

        BNode<Integer> raiz = new BNode<>(50);
        BNode<Integer> A = new BNode<>(5);

        raiz.setLeft(A);
        BNode<Integer> teste = raiz;

        BTree<Integer> tree1 = new BTree<>(15,new BNode<>(30),new BNode<>(20));





    }
}
