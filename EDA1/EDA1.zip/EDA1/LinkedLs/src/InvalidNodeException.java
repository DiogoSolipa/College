public class InvalidNodeException extends RuntimeException {


}
