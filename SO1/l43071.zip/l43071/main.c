#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "queue.h"

int nLines(FILE *fp)
{
    int count = 0;  // Line counter (result) 
    char c;  // To store a character read from file

    // Check if file exists 
    if (fp == NULL) 
    { 
        printf("Could not open file %s", "/home/ds/Desktop/College/Implementations/Queue/test.txt"); 
        return 0; 
    } 
  
    // Extract characters from file and store in character c 
    for (c = getc(fp); c != EOF; c = getc(fp)) 
        if (c == '\n') // Increment count if this character is newline 
            count++; 
  
    return count;
}

void moveBlocked(struct list *blocked, struct Process *p)
{
    list_insert(blocked, p);
}

void blockedReady(struct list *blocked, struct Queue *ready)
{
    struct node *node = first(blocked);
    struct Process *p;

    while (node != NULL)
    {
        p = nodeProcess(node);
        instantIo(p, ready, blocked);
        node = next(node);  
    }
}

/*
compara um PID de um Processo do array de Processos com a Queue de int PIDs
Se este existir retorna o Processo correspondente a esse PID
*/

struct Process *compare(int size, struct Process *arr[size], int pid)
{

    for (int i = 0; i < size; i++)
    {
        if (getPid(arr[i]) == pid)
        {
            //printf("%dA\n", pid);
            return arr[i];
        }
    }

    return arr[0];
}

void print(struct Queue *ready, struct Queue *run, struct list *blocked, int count)
{
    printf("%d READY ", count);

    printQueue(ready);

    //printf("\t");

    printf("RUN ");

    printQueue(run);

    //printf("\t");

    printf("BLOCKED ");

    list_print(blocked);

    printf("\n");
}


int main(void) 
{ 
    FILE *fp = fopen("/home/ds/Desktop/College/Implementations/Queue/test.txt", "r"); 
    int lines = nLines(fp);
    fclose(fp);

    //struct Queue *queue = queue_new(lines);
    struct Queue *run = queue_new(lines);
    struct Queue *ready = queue_new(lines);
    
    struct Process *p;

    struct Process *array[lines];

    struct list *blocked = list_new();

    char s[SIZE_S];
    char str[4];

    int pid = 0;
    int entry = 0;
    int arr[SIZE];

    int index = 0;
    int counter = 0;
    int it = 0;
    int time = 0;
       
    while(fgets(s, SIZE_S, stdin))
    { 
        memcpy(str, s, 3);
        str[3] = '\0';

        pid = atoi(str);

        entry = s[4] - '0';

        for (int i = 0; i < SIZE; i++)
        {
            arr[i] = 0;
        }

        for (int i = 0; i < strlen(s); i++)
        {
            if (i > 5 && s[i] != '\n' &&& s[i])
            {

                counter = i;

                while (s[counter] != ' ') //caso de haverem istantes maior que unidades, o numero de chars e counter - i
                {
                    counter++;
                }

                char n[counter - i + 1];

                memcpy(n, &s[i], counter - i);
                n[counter -i] = '\0';

                arr[index] = atoi(n);
                time += arr[index];
                index++;

                i = counter++;
            }       
        }
        index = 0;
        
        p = process_new(pid, entry, arr);

        array[it] = p;
        it++;
    }



    int count = 0;
    int aux = 0;

    for (int i = 0; i < it; i++)
    {
        if (getEntry(array[i]) == count)
        {
            enqueue(array[i], ready);
            aux = i;
            aux++;
        }
    }

    int inst = 0;

    //printf("Round Robin Quantum %d\n", QUANTUM);
    printf("FCFS\n");

    while (isEmpty(ready) == false || isEmpty(run) == false || list_empty(blocked) == false)
    {
        //Entrar no Run inicial
        if (isEmpty(run) == true && isEmpty(ready) == false)
        {
            enqueue(compare(lines, array, dequeue(ready)), run);
            p = getRunProcess(run, lines, array);
        }
        //remover do Run se tCPU == 0 e por no Blocked
        if (isEmpty(run) == false)
        {
            inst = instantCpu(p, run, blocked, ready, inst);
        }
        //Se foi removido entao tem de entrar logo outro
        if (isEmpty(run) == true && isEmpty(ready) == false)
        {
            enqueue(compare(lines, array, dequeue(ready)), run);
            p = getRunProcess(run, lines, array);

            //caso em que entrou um processo no RUN logo apos a remocao de outro e tem de se decrementar o tCPU
            if (isEmpty(run) == false)
            {
                inst = instantCpu(p, run, blocked, ready, inst);
            }
        }

        //passagem Blocked -> Ready
        if(list_empty(blocked) == false)
        {
            blockedReady(blocked, ready);

            //Se foi removido do Blocked->Ready e RUN empty--> entao tem de entrar logo outro
            if (isEmpty(run) == true && isEmpty(ready) == false)
            {
                enqueue(compare(lines, array, dequeue(ready)), run);
                p = getRunProcess(run, lines, array);

                //caso em que entrou um processo no RUN logo apos a remocao de outro e tem de se decrementar o tCPU
                if (isEmpty(run) == false)
                {
                    inst = instantCpu(p, run, blocked, ready, inst);
                }
            }
        }

        for (int i = aux; i < it; i++)
        {
            if (getEntry(array[i]) == count)
            {
                enqueue(array[i], ready);
            }
        }

        print(ready, run, blocked, count);

        count++;
    }

    list_destroy(blocked);
}