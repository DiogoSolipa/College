#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

struct Queue
{
    int size;
    int *arr;
    int front;
    int end;
};

struct Process 
{
    int pid;
    int entry;
    int arr[SIZE];
};

struct Process *process_new(int n, int entry, int array[SIZE])
{
    struct Process *p = malloc(sizeof(struct Process));

    if (p != NULL)
    {
        p->pid = n;
        p->entry = entry;
        for (int i = 0; i < SIZE; i++)
        {
            p->arr[i] = array[i];
        }
    }

    return p;
}

struct Queue *queue_new(int n)
{
    struct Queue *queue = malloc(sizeof(struct Queue));

    if (queue != NULL)
    {
        queue->size = n;
        queue->front = queue->end = 0;
        queue->arr = malloc(queue->size * sizeof(int));

        for (int i = 0; i < queue->size; i++)
        {
        queue->arr[i] = 0;
        }
    }
    return queue;
}

bool isFull (struct Queue *queue)
{
    return queue->size == queue->end - queue->front;
}
/*
vazia == isEmpty == true ; queue->end == 0 --> true
*/
bool isEmpty(struct Queue *queue)
{
    for (int i = 0; i < queue->size; i++)
    {
        if (queue->arr[i] != 0)
        {
            return false;
        }
    }

    return true;
}

int inc(int pos, struct Queue *queue)
{
    return (pos + 1) % queue->size;
}

void enqueue (struct Process *p, struct Queue *queue)
{
    if (isFull(queue))
        return;


    queue->arr[queue->end] = p->pid;
    queue->end = inc(queue->end, queue);
}

int dequeue(struct Queue *queue)
{
    int n = 0;

    if (isEmpty(queue))
        return -1;
    
    n = queue->arr[queue->front];
    queue->arr[queue->front] = 0;
    queue->front = inc(queue->front, queue);

    return n;
}

int end(struct Queue *queue)
{
    return queue->end;
}

int getPid(struct Process *p)
{
    return p->pid;       
}

int getEntry(struct Process *p)
{
    return p->entry;
}

struct Process *getRunProcess(struct Queue *queue, int size,  struct Process *arr[size])
{
    return compare(size, arr, queue->arr[queue->front]);
}

int instantCpu(struct Process *p, struct Queue *run, struct list *blocked, struct Queue *ready, int inst)
{
    /*if (inst == QUANTUM)
    {
        enqueue(p, ready);
        dequeue(run);
        inst = 0;
    }
    else{ descomentar para Round Robin*/
    
        if (p->arr[0] == 0 && p->arr[1] != 0)
            {
                moveBlocked(blocked, p);
                dequeue(run);
                inst = 0;
            }
            else if (p->arr[0] > 0)
            {
                p->arr[0]--;
                inst++;   
            }
            else if (p->arr[2] == 0 && p->arr[3] != 0)
            {
                moveBlocked(blocked, p);
                dequeue(run);
                inst = 0;
            }
            else if (p->arr[2] > 0)
            {
                p->arr[2]--;
                inst++;
            }
            else if(p->arr[4] == 0)
            {
                dequeue(run);
                inst = 0;
            }
            else if (p->arr[4] > 0)
            {
                p->arr[4]--;
                inst++; 
            }
    //} descomentar para Round Robin

    return inst;
}

void instantIo(struct Process *p, struct Queue *ready, struct list *blocked)
{
    if (p->arr[1] == 0 && p->arr[2] != 0)
    {
        if(list_remove(blocked, p))
        {
            enqueue(p, ready);
        }
            
    }
    else if(p->arr[1] > 0)
    {
        p->arr[1]--;
    }
    else if(p->arr[3] == 0 && p->arr[4] != 0)
    {
        if(list_remove(blocked, p))
        {
            enqueue(p, ready);
        }
            
    }
    else if(p->arr[3] > 0)
    {
        p->arr[3]--;
    }
}

void printQueue(struct Queue *q)
{
    for (int i = 0; i < q->size; i++)
    {
        if (q->arr[i] != 0)
            printf("%d ", q->arr[i]);
    }

    for (int i = 0; i< q->size; i++)
    {
        if(q->arr[i] == 0)
            printf("    ");
    } 

}