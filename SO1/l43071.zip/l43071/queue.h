# include <stdbool.h>
# include "list.h"

#define SIZE 5
#define SIZE_S 19
#define QUANTUM 3

struct Queue;
struct Process;

struct Queue *queue_new(int n);
struct Process *process_new(int n, int entry, int arr[SIZE]);
bool isFull(struct Queue *queue);
bool isEmpty(struct Queue *queue);
void enqueue (struct Process *p, struct Queue *queue);
int dequeue (struct Queue *queue);
int end (struct Queue *queue);
int getPid(struct Process *p);
int getEntry(struct Process *p);
void printQueue(struct Queue *q);
struct Process *getRunProcess(struct Queue *queue,int size, struct Process *arr[size]);
int instantCpu(struct Process *p, struct Queue *run, struct list *blocked, struct Queue *ready, int inst);
struct Process *compare(int size, struct Process *arr[size], int pid);
void moveBlocked(struct list *blocked, struct Process *p);
void printProcess(struct Process *p);
void instantIo(struct Process *p, struct Queue *ready, struct list *blocked);
int dequeueReady(struct Queue *ready, struct Process *p);