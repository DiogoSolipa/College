#include <stdbool.h>

struct list;
struct node;

struct list *list_new();
struct Process *list_insert(struct list *list, struct Process *p);
void list_print(struct list *list);
struct list *list_destroy(struct list *list);
bool list_empty(struct list *list);
struct Process *list_find(struct list *list, struct Process *p);
bool list_remove(struct list *list, struct Process *p);
int list_length(struct list *list);
struct node *first(struct list *l);
struct node *next(struct node *node);
struct Process *nodeProcess(struct node *node);
